package com.politecnico.operaciones;

public class Multiplicacion {

    public double multiplicar(double a, double b){
        return a * b;
    }

    public int multiplicar(int a, int b){
        return a * b;
    }

    public double multiplicar(double a, double b, double c){
        return a * b * c;
    }
}
